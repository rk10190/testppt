# Spring Boot AWS SQS Listener Example
Spring Boot AWS SQS Listener Example 
#See complete example here(https://www.netsurfingzone.com/aws/spring-boot-aws-sqs-listener-example/).

The above example covers below topics.
1. AWS Management Console setup for Spring Boot AWS SQS listener example.
2. Spring Boot AWS SQS Configuration.
3. Spring Boot AWS SQS Listener example from scratch
4. How to set up AWS Credentials(access key and secret key) environment variable in the windows.
5. Spring Boot AWS SQS Listener example using two separate instances(Tomcat)
6. Basic points about AWS SQS.

