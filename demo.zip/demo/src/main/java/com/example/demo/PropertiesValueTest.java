package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

@Service
@PropertySource("classpath:application-dev.properties")
public class PropertiesValueTest {
  
  @Value("${core.service.invocation.required:false}")
  private Boolean invocationRequired;
  
  public void print() {
    System.out.println("################# Value :"+invocationRequired);
  }
  

}
