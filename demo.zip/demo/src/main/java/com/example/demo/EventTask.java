package com.example.demo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * The Class EventTask represents the task to be executed by spring batch.
 *
 * @author kumarr55
 */
@Component
public class EventTask implements Tasklet {

  private static final Logger LOG = LogManager.getLogger(EventTask.class);

  @Autowired
  private PropertiesValueTest startup;

  /**
   * This is a task function and will be executed according to the spring batch trigger defined by
   * job-runner
   *
   * @param contribution the contribution
   * @param chunkContext the chunk context
   * @return the repeat status
   * @throws Exception the exception
   */
  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
    try {
      startup.print();
    } catch (Exception e) {
      LOG.error(e.getMessage(), e);
    }
    return RepeatStatus.FINISHED;
  }

}
