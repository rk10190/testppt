package com.example.demo;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * The Class BatchConfig for configuring the batch process and create beans for Step and Job.
 *
 * @author kumarr55
 */
@Configuration
@EnableBatchProcessing
public class BatchConfig {

  @Autowired
  private JobBuilderFactory jobs;

  @Autowired
  private StepBuilderFactory steps;

  @Autowired
  private EventTask eventTask;

  /**
   * Gets the job object.
   *
   * @return the job object
   */
  @Bean
  public Job getJobObject() {
    return jobs.get("Fetch_SQS_Message_Job").incrementer(new RunIdIncrementer()).start(getStepObject()).build();
  }

  /**
   * Gets the step object.
   *
   * @return the step object
   */
  private Step getStepObject() {
    return steps.get("Fetch_SQS_Message_Step").tasklet(eventTask).build();
  }
}
