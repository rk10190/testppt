/*
 * Copyright (c) 2019 Caterpillar Inc. All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished proprietary information which may constitute a
 * trade secret and/or be confidential. This work may be used only for the purposes for which it was
 * provided, and may not be copied or disclosed to others. Copyright notice is precautionary only,
 * and does not imply publication.
 */

/**
 *
 */
package com.example.demo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * Entry to program. There is a listener (com.cat.sw.copy.Startup) that actually starts the app when
 * Spring is done starting.
 * 
 * @author varshv
 */
@SpringBootApplication
@EnableConfigurationProperties
public class Application {

  private static final Logger LOG = LogManager.getLogger(Application.class);

  @Autowired
  JobLauncher jobLauncher;

  @Autowired
  Job job;

  public static void main(String[] args) {
    SpringApplication.run(Application.class, args);
  }

  /**
   * Perform the job execution that consists the step and task for the particular step. It executes
   * based on the scheduled timings provided in cron expression with @scheduled
   *
   * @throws Exception the exception
   */
  @Scheduled(cron = "0 */2 * * * ?")
  public void perform() {
    JobParameters params =
        new JobParametersBuilder().addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();
    try {
      jobLauncher.run(job, params);
    } catch (Exception e) {
      LOG.error(e.getMessage(), e);
    }
  }
}
